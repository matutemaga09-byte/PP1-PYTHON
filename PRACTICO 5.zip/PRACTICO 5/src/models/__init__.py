# Importar todos los modelos de SQLModel para registrarlos en SQLModel.metadata
from models.marcas import Marca
from models.autos import Auto

__all__ = ["Marca", "Auto"]
