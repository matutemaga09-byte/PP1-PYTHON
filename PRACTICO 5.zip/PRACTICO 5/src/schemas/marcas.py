from typing import TYPE_CHECKING, Optional
from sqlmodel import Field, SQLModel

if TYPE_CHECKING:
    from schemas.autos import AutoRead


class MarcaBase(SQLModel):
    """Schema base con campos compartidos para Marca."""
    nombre: str = Field(min_length=2, max_length=50, description="Nombre de la marca")


class MarcaCreate(MarcaBase):
    """Schema para la creación de una nueva marca."""
    pass


class MarcaUpdate(SQLModel):
    """Schema para la actualización parcial o total de una marca."""
    nombre: Optional[str] = Field(
        default=None, min_length=2, max_length=50, description="Nombre de la marca"
    )


class MarcaRead(MarcaBase):
    """Schema de lectura simple para Marca."""
    id: int = Field(gt=0, description="Identificador único de la marca")


class MarcaReadWithAutos(MarcaRead):
    """Schema anidado: Marca incluyendo la lista de sus autos asociados."""
    autos: list["AutoRead"] = []
