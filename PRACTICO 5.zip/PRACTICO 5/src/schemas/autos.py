from typing import Optional
from sqlmodel import Field, SQLModel

from schemas.marcas import MarcaRead, MarcaReadWithAutos


class AutoBase(SQLModel):
    """Schema base con campos compartidos para Auto."""
    marca_id: int = Field(gt=0, description="ID de la marca a la que pertenece el auto")
    modelo: str = Field(min_length=1, max_length=30, description="Modelo del vehículo")
    anio: int = Field(ge=1900, le=2100, description="Año del vehículo")
    precio: float = Field(gt=0, description="Precio del vehículo")


class AutoCreate(AutoBase):
    """Schema para la creación de un nuevo auto."""
    pass


class AutoUpdate(SQLModel):
    """Schema para la actualización parcial o total de un auto."""
    marca_id: Optional[int] = Field(default=None, gt=0, description="ID de la marca")
    modelo: Optional[str] = Field(default=None, min_length=1, max_length=30, description="Modelo")
    anio: Optional[int] = Field(default=None, ge=1900, le=2100, description="Año del vehículo")
    precio: Optional[float] = Field(default=None, gt=0, description="Precio del vehículo")


class AutoRead(AutoBase):
    """Schema de lectura simple para Auto."""
    id: int = Field(gt=0, description="Identificador único del auto")


class AutoReadWithMarca(AutoRead):
    """Schema anidado: Auto incluyendo los datos de su Marca asociada."""
    marca: Optional[MarcaRead] = None


# Reconstruir schemas con referencias diferidas para soportar anidamiento
MarcaReadWithAutos.model_rebuild(_types_namespace={"AutoRead": AutoRead})
AutoReadWithMarca.model_rebuild()

# Alias de conveniencia para retrocompatibilidad
Auto = AutoReadWithMarca
